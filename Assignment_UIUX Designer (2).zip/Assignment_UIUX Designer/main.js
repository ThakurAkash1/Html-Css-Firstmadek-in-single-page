document.addEventListener('DOMContentLoaded', function() {
  const form = document.getElementById('company-profile-form');

  form.addEventListener('submit', function(event) {
    event.preventDefault(); 

    // Validate form fields
    const companyName = document.getElementById('company-name').value.trim();
    const industry = document.getElementById('industry').value.trim();
    const description = document.getElementById('description').value.trim();

    if (!companyName || !industry || !description) {
      alert('Please fill out all fields.');
      return;
    }
    console.log('Company Name:', companyName);
    console.log('Industry:', industry);
    console.log('Description:', description);

    // Optionally, you can reset the form after submission
    form.reset();
  });
});



document.addEventListener('DOMContentLoaded', function() {
  const form = document.getElementById('job-posting-form');

  form.addEventListener('submit', function(event) {
    event.preventDefault(); 

    // Validate form fields
    const jobTitle = document.getElementById('job-title').value.trim();
    const jobCategory = document.getElementById('job-category').value.trim();
    const jobDescription = document.getElementById('job-description').value.trim();

    if (!jobTitle || !jobCategory || !jobDescription) {
      alert('Please fill out all fields.');
      return;
    }

    // For now, let's just log the form data
    console.log('Job Title:', jobTitle);
    console.log('Job Category:', jobCategory);
    console.log('Job Description:', jobDescription);

    // Optionally, you can reset the form after submission
    form.reset();
  });
});

//serach 
document.addEventListener('DOMContentLoaded', function() {
  const searchButton = document.getElementById('search-button');

  searchButton.addEventListener('click', function() {
    const searchInput = document.getElementById('search-input').value.trim();
    const skillFilter = document.getElementById('skill-filter').value.trim();
    const locationFilter = document.getElementById('location-filter').value.trim();
    
    // Perform search logic based on the input values
    console.log('Search Input:', searchInput);
    console.log('Skill Filter:', skillFilter);
    console.log('Location Filter:', locationFilter);

    // Example: Simulate search results
    displaySearchResults([
      { name: 'John Doe', skills: 'Web Development, UI/UX Design', location: 'Bangalore, India' },
      { name: 'Jane Smith', skills: 'Graphic Design, Illustration', location: 'Mumbai, India' },
      // Add more search results as needed
    ]);
  });

  function displaySearchResults(results) {
    const searchResults = document.getElementById('search-results');
    searchResults.innerHTML = ''; // Clear previous search results

    results.forEach(result => {
      const resultCard = document.createElement('div');
      resultCard.classList.add('col-md-6', 'col-lg-4', 'mb-4');

      resultCard.innerHTML = `
        <div class="card h-100">
          <div class="card-body">
            <h3 class="card-title">${result.name}</h3>
            <p class="card-text"><strong>Skills:</strong> ${result.skills}</p>
            <p class="card-text"><strong>Location:</strong> ${result.location}</p>
            <button class="btn btn-success contact-button">Contact</button>
          </div>
        </div>
      `;

      searchResults.appendChild(resultCard);
    });
  }
});
