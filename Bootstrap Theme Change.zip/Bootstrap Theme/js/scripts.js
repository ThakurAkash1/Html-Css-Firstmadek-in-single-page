/*!
* Start Bootstrap - Freelancer v7.0.6 (https://startbootstrap.com/theme/freelancer)
* Copyright 2013-2022 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-freelancer/blob/master/LICENSE)
*/
//
// Scripts
// 

window.addEventListener('DOMContentLoaded', event => {

    // Navbar shrink function
    var navbarShrink = function () {
        const navbarCollapsible = document.body.querySelector('#mainNav');
        if (!navbarCollapsible) {
            return;
        }
        if (window.scrollY === 0) {
            navbarCollapsible.classList.remove('navbar-shrink')
        } else {
            navbarCollapsible.classList.add('navbar-shrink')
        }

    };
    

    // Shrink the navbar 
    navbarShrink();

    // Shrink the navbar when page is scrolled
    document.addEventListener('scroll', navbarShrink);

    // Activate Bootstrap scrollspy on the main nav element
    const mainNav = document.body.querySelector('#mainNav');
    if (mainNav) {
        new bootstrap.ScrollSpy(document.body, {
            target: '#mainNav',
            offset: 72,
        });
    };

    // Collapse responsive navbar when toggler is visible
    const navbarToggler = document.body.querySelector('.navbar-toggler');
    const responsiveNavItems = [].slice.call(
        document.querySelectorAll('#navbarResponsive .nav-link')
    );
    responsiveNavItems.map(function (responsiveNavItem) {
        responsiveNavItem.addEventListener('click', () => {
            if (window.getComputedStyle(navbarToggler).display !== 'none') {
                navbarToggler.click();
            }
        });
    });

});
var sliderControl = document.querySelector(".slider-control");

// slides informations

var slides = document.querySelectorAll(".slide"),
    slidesLength = slides.length;

// slides array

var slidesArr = [].slice.call(slides);

// reverse array sorting

slidesArr = slidesArr.reverse();


// slide current
var slideCurrent = 0;

sliderControl.addEventListener("click", function(e){
  target = e.target;

  // Get next button
  if(target.classList.contains("next")){
    next = e.target,
    prev = next.previousElementSibling,
    nextSlide = slidesArr[slideCurrent + 1],
    slide = slidesArr[slideCurrent];

    slide.classList.add("slide-on");
    slide.classList.remove("text-on");
    nextSlide.classList.add("text-on");

    slideCurrent += 1;        
    if(slideCurrent > 0) {
      prev.classList.remove("disabled");
    }         
    if(slideCurrent === slidesLength - 1){
      next.classList.add("disabled");
    }
}     

// get prev button
   if(target.classList.contains("prev")){

    slideCurrent -= 1;

    prev = e.target,
    next = prev.nextElementSibling,
    prevSlide = slidesArr[slideCurrent + 1],
    slidesArr[slideCurrent];
    prevSlide.classList.remove("text-on");
    slide.classList.remove("slide-on");
    slide.classList.add("text-on");

    if(slideCurrent === slidesLength - 2){
      next.classList.add("disabled");
    }
    if(slideCurrent === 0){
    prev.classList.add("disabled");}

   }        
});
